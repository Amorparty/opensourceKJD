﻿using System;

namespace WSE_Core
{
    public class Class1
    {
    }
}
