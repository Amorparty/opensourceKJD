﻿using System;

namespace Morpheme
{
    public class Class1
    {
    }
}
