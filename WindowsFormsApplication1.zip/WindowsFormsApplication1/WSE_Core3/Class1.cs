﻿using System;

namespace WSE_Core3
{
    public class Class1
    {
    }
}
