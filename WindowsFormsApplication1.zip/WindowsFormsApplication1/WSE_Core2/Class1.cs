﻿using System;

namespace WSE_Core2
{
    public class Class1
    {
    }
}
